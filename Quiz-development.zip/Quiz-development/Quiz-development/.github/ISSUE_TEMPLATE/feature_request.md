---
name: Feature request
about: Suggest an feature for the project

---

**Describe the feature you'd like**

<!-- A clear and concise description of what you want to happen.-->

**Additional context**

<!-- Add any other context about the problem here.-->

**Screenshots**

<!--Where-ever possible add a screenshot of the issue.-->

**Would you like to work on the issue?**

<!--Let us know if this issue should be assigned to you or tell us who you think could help to solve this issue.-->
